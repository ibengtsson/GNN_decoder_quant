//Numpy array shape [1]
//Min 0.085171334445
//Max 0.085171334445
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
model_default_t b4[1];
#else
model_default_t b4[1] = {0.0851713344};
#endif

#endif
