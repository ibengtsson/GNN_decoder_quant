//Numpy array shape [32]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 32

#ifndef B20_H_
#define B20_H_

#ifndef __SYNTHESIS__
bias20_t b20[32];
#else
bias20_t b20[32] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
#endif

#endif
